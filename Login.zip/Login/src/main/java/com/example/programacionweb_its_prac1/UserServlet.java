package com.example.programacionweb_its_prac1;

import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.util.Base64;

import io.jsonwebtoken.Claims;

import static com.example.programacionweb_its_prac1.AutenticacionServlet.generalKey;

@WebServlet("/user-servlet/*")
public class UserServlet extends HttpServlet {
    private final JsonResponse jResp = new JsonResponse();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        String authTokenHeader = req.getHeader("Authorization");
        validateAuthToken(req, resp, authTokenHeader.split(" ")[1]);
    }

    /**
     * Método que se utiliza para validar el token de autenticación. Si el token es válido, se envía una respuesta exitosa.
     * Si el token no es válido, se envía una respuesta fallida.
     * @param req
     * @param resp
     * @param token Token de autenticación
     * @throws IOException
     */

    // Dentro del método validateAuthToken en UserServlet.java
    private void validateAuthToken(HttpServletRequest req, HttpServletResponse resp, String token) throws IOException {
        JwtParser jwtParser = Jwts.parser()
                .verifyWith(generalKey())
                .build();
        try {
            Claims claims = jwtParser.parseClaimsJws(token).getBody();
            User user = new User();
            user.setFullName(claims.get("fullName", String.class));
            user.setEmail(claims.get("email", String.class));
            user.setUsername(claims.get("username", String.class));
            user.setJwt(token);

            // Construir el JSON de respuesta excluyendo la contraseña
            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("fullName", user.getFullName());
            jsonResponse.put("email", user.getEmail());
            jsonResponse.put("username", user.getUsername());
            jsonResponse.put("jwt", user.getJwt());

            // Escribir la respuesta JSON en el cuerpo de la respuesta HTTP
            resp.setContentType("application/json");
            resp.getWriter().write(jsonResponse.toString());
        } catch (Exception e) {
            jResp.failed(req, resp, "Unauthorized: " + e.getMessage(), 401);
        }
    }

}